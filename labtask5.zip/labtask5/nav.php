 <ul>
        <li><a href="addProduct.php"> Add product</a></li>
        <li><a href="showAllProducts.php"> Show all products</a></li>
        <li><a href="searchProduct.php"> Search product</a></li>
    </ul>